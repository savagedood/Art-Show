
let x = 0;
let y = 0;
let spacing = 10;

function setup() {
  createCanvas(400, 400);
  background(0);
}

function draw() {
  background(0);

}

function draw() {
  stroke(255)
  if (random(1) < 0.5) {
    line(x, y, x + 1000, y + 50);
  } else {
    line(x, y + 100, x + 10, y);
  }
  x = x + 10;
  if (x > width) {
    x = 0;
    y = y +10;
  }
}